import { useState, useEffect, useRef } from "react";
import { IntroShell } from "./components/IntroShell";
import { Hero } from "./components/Hero";
import {
  About,
  Community,
  Experience,
  Footer,
  Hackathons,
  HowItWorks,
  JoinCTA,
  Marquee,
  Mission,
} from "./components/Sections";

function useReducedMotion() {
  const [reduced, setReduced] = useState(() =>
    typeof window === "undefined"
      ? false
      : window.matchMedia("(prefers-reduced-motion: reduce)").matches,
  );

  useEffect(() => {
    const query = window.matchMedia("(prefers-reduced-motion: reduce)");
    const onChange = (event: MediaQueryListEvent) => setReduced(event.matches);
    query.addEventListener("change", onChange);
    return () => query.removeEventListener("change", onChange);
  }, []);

  return reduced;
}

export default function App() {
  const reducedMotion = useReducedMotion();
  const heroProgress = useRef(0);

  return (
    <div className="campus-landing" id="top">
      <a className="skip-link" href="#about">
        SKIP INTRO
      </a>
      <IntroShell reducedMotion={reducedMotion} />
      <Hero progress={heroProgress} reducedMotion={reducedMotion} />
      <main>
        <Marquee />
        <About progress={{ current: 0 }} reducedMotion={reducedMotion} />
        <Experience />
        <HowItWorks />
        <Hackathons />
        <Mission />
        <Community />
        <JoinCTA />
      </main>
      <Footer />
    </div>
  );
}
