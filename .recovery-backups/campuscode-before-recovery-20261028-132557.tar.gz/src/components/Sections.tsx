import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { CubeScene, type ProgressRef } from "./CubeScene";

export { CubeScene } from "./CubeScene";

const STEPS = [
  { number: "01", title: "DISCOVER", text: "Find a challenge that makes you want to build." },
  { number: "02", title: "TEAM UP", text: "Find people who share your ambition." },
  { number: "03", title: "BUILD", text: "Turn your idea into something people can use." },
  { number: "04", title: "SHIP", text: "Submit your work and take it to the arena." },
];

const HACKATHONS = [
  {
    number: "01",
    category: "ARTIFICIAL INTELLIGENCE",
    title: "AI INNOVATION",
    description: "Build intelligent solutions for problems that matter.",
    status: "LIVE",
  },
  {
    number: "02",
    category: "WEB DEVELOPMENT",
    title: "FUTURE WEB",
    description: "Design and ship the next generation of digital experiences.",
    status: "OPEN",
  },
  {
    number: "03",
    category: "SMART TECHNOLOGY",
    title: "CAMPUS TECH",
    description: "Create technology that makes student life better.",
    status: "UPCOMING",
  },
];

export function Marquee() {
  const MARQUEE_ITEMS = ["IDEAS", "PEOPLE", "PRODUCTS", "INNOVATION", "COMMUNITY"];
  const track = [...MARQUEE_ITEMS, ...MARQUEE_ITEMS, ...MARQUEE_ITEMS];
  return (
    <section className="landing-marquee" aria-label="CampusCode values">
      <div className="marquee-track" aria-hidden="true">
        {track.map((item, index) => (
          <span key={`${item}-${index}`} className="marquee-unit">
            <span>{item}</span>
            <b>✦</b>
          </span>
        ))}
      </div>
    </section>
  );
}

export function Experience() {
  return (
    <section className="landing-experience">
      <div className="experience-body">
        <div className="experience-visual">
          <div className="experience-player">
            <button className="experience-play"><i>&bull;</i></button>
            <span className="experience-time">02:34</span>
            <div className="experience-watch">
              <a href="#" className="experience-watch-link">Watch it again &raquo;</a>
              <a href="#" className="experience-scroll-link">Explore more &raquo;</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export function HowItWorks() {
  return (
    <section className="landing-how" id="howitworks">
      <div className="section-heading">
        <h2>HOW IT WORKS</h2>
        <p>See what students are building today.</p>
        <a href="#hackathons" className="section-link">Jump to Hackathons &raquo;</a>
      </div>
      <div className="steps-grid">
        {STEPS.map((step) => (
          <div className="step-card" key={step.number}>
            <div className="step-number">{step.number}</div>
            <div className="step-line" />
            <h3>{step.title}</h3>
            <p>{step.text}</p>
            <span className="step-arrow">&rarr;</span>
          </div>
        ))}
      </div>
    </section>
  );
}

export function Hackathons() {
  return (
    <section className="landing-hackathons" id="hackathons">
      <div className="section-heading">
        <h2>ENTER THE ARENA</h2>
        <p>Active challenges right now.</p>
      </div>
      <div className="hackathon-list">
        {HACKATHONS.map((hack) => (
          <div className="hackathon-row" key={hack.number}>
            <span className="hack-number">{hack.number}</span>
            <div className="hack-title">
              <h3>{hack.category}</h3>
              <small>{hack.title}</small>
              <p>{hack.description}</p>
            </div>
            <span className="hack-status">
              <i className={hack.status === "LIVE" ? "active" : ""} />
              {hack.status}
            </span>
            <span className="hack-arrow">&rarr;</span>
          </div>
        ))}
      </div>
    </section>
  );
}

export function Mission() {
  return (
    <section className="landing-statement">
      <div className="statement-content">
        <span>VALUED VALUES</span>
        <h2>CAMPUSCODE <em>REWRITES</em></h2>
        <p>Connecting students to real-world problems through organized events, shared tools, and a community that drives innovation.</p>
      </div>
    </section>
  );
}

export function Community() {
  return (
    <section className="landing-community">
      <div className="community-left">
        <span>THE NETWORK</span>
        <h2>STUDENT COMMUNITY</h2>
        <div className="community-meta">
          <span>&rsaquo; Events</span>
          <span>&rsaquo; Mentors</span>
          <span>&rsaquo; Teams</span>
          <span>&rsaquo; Prizes</span>
        </div>
      </div>
      <div className="community-right">
        <div className="community-orbit">
          <strong>CC</strong>
          <span /><span /><span /><span /><span />
        </div>
        <p>A connected space where every idea starts to matter.</p>
      </div>
    </section>
  );
}

export function JoinCTA() {
  return (
    <section className="landing-cta" id="joincampuscode">
      <div className="cta-grid" aria-hidden="true" />
      <div className="cta-orb" aria-hidden="true" />
      <div className="cta-content">
        <small>JOIN US TODAY</small>
        <h2>FINAL JOIN CAMPUSCODE</h2>
        <a href="#" className="cta-button">GET STARTED <span>&rsaquo;</span></a>
      </div>
    </section>
  );
}

export function Footer() {
  const columns = [
    { title: "Quick Links", links: ["About Us", "Careers", "Contact"] },
    { title: "Company", links: ["Our Story", "Press", "Privacy"] },
    { title: "Resources", links: ["Blog", "Forum", "Docs"] },
  ];

  return (
    <footer className="landing-footer">
      <div className="footer-watermark">CampusCode</div>
      <div className="footer-main">
        <div className="footer-logo">
          <strong>&laquo; CampusCode &raquo;</strong>
          <span>logo mark</span>
        </div>
        <div className="footer-brand">
          <p>Building the future of student tech, together.</p>
        </div>
        {columns.map((col) => (
          <div className="footer-column" key={col.title}>
            <h4>{col.title}</h4>
            {col.links.map((link) => (
              <a href="#">{link}</a>
            ))}
          </div>
        ))}
      </div>
      <div className="footer-status">
        <div><i /> Active projects</div>
        <a href="#">Join the community &rsaquo;</a>
      </div>
      <div className="footer-bottom">
        <span>&copy; CampusCode 2026</span>
        <span>All rights reserved</span>
      </div>
    </footer>
  );
}

export function About({ progress, reducedMotion }: { progress: ProgressRef; reducedMotion: boolean }) {
  const sectionRef = useRef<HTMLElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const logoRef = useRef<HTMLDivElement>(null);
  const badgeRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const card = cardRef.current;
    const logo = logoRef.current;
    const badge = badgeRef.current;
    if (!section || !card || !logo || !badge) return;

    const ctx = gsap.context(() => {
      const leadRef = section.querySelector(".about-lead");

      const markers = gsap.utils.toArray<HTMLElement>(".about-marker", section);
      const cornerTop = section.querySelector(".about-cc-corner-top") as HTMLElement | null;
      const cornerBot = section.querySelector(".about-cc-corner-bot") as HTMLElement | null;

      // Headline: WHERE, STUDENTS, BUILD. reveal in sequence
      const lines = gsap.utils.toArray<HTMLElement>(".about-headline-line", section);

      lines.forEach((line, i) => {
        line.style.display = "block";
        line.style.opacity = "0";
        line.style.transform = "translateY(40px)";
        gsap.fromTo(line, { opacity: 0, y: 40 }, {
          opacity: 1,
          y: 0,
          duration: 0.55 + i * 0.12,
          ease: "power2.out",
          scrollTrigger: {
            trigger: section,
            start: "top 80%",
            toggleActions: "play none none reverse",
          },
        });
      });

      // Lead text appears after the headline
      if (leadRef) {
        gsap.fromTo(leadRef, { opacity: 0, y: 30 }, {
          opacity: 1,
          y: 0,
          duration: 0.5,
          ease: "power2.out",
          scrollTrigger: {
            trigger: section,
            start: "top 72%",
            toggleActions: "play none none reverse",
          },
        });
      }

      // Information card smooth scroll-triggered reveal
      gsap.fromTo(card, { opacity: 0, y: 60 }, {
        opacity: 1,
        y: 0,
        duration: 0.7,
        ease: "power3.out",
        scrollTrigger: {
          trigger: section,
          start: "top 78%",
          toggleActions: "play none none reverse",
        },
      });

      // Badge / CC square fade in
      gsap.fromTo(badge, { scale: 0.6, opacity: 0 }, {
        scale: 1,
        opacity: 1,
        duration: 0.5,
        ease: "back.out(1.7)",
        scrollTrigger: {
          trigger: section,
          start: "top 82%",
          toggleActions: "play none none reverse",
        },
      });

      // 3D logo y fade in
      gsap.fromTo(logo, { opacity: 0, y: 18 }, {
        opacity: 1,
        y: 0,
        duration: 0.4,
        ease: "power2.out",
        scrollTrigger: {
          trigger: section,
          start: "top 84%",
          toggleActions: "play none none reverse",
        },
      });

      // Border pulse + marker movement
      gsap.to(".about-right-card", {
        borderColor: "rgba(0,0,0,0.55)",
        duration: 1.2,
        ease: "sine.inOut",
        repeat: -1,
        yoyo: true,
        scrollTrigger: {
          trigger: section,
          start: "top 80%",
          end: "bottom 80%",
          toggleActions: "play none none none",
        },
      });

      markers.forEach((marker) => {
        gsap.to(marker, {
          opacity: 0.5,
          duration: 1.4,
          ease: "sine.inOut",
          repeat: 1,
          yoyo: true,
          scrollTrigger: {
            trigger: section,
            start: "top 80%",
            toggleActions: "play none none none",
          },
        });
      });

      [cornerTop, cornerBot].forEach((el) => {
        if (!el) return;
        gsap.to(el, {
          borderColor: "rgba(0,0,0,0.4)",
          duration: 1.1,
          ease: "sine.inOut",
          repeat: -1,
          yoyo: true,
          scrollTrigger: {
            trigger: section,
            start: "top 80%",
            end: "bottom 80%",
            toggleActions: "play none none none",
          },
        });
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section id="about" className="landing-about" ref={sectionRef}>
      <div className="about-left">
        <div className="section-number">01 — WHAT IS CAMPUSCODE?</div>
        <div className="small-label">
          <i aria-hidden="true" />
          WHAT IS CAMPUSCODE?
        </div>
        <h2 className="about-headline">
          <span className="about-headline-line">WHERE</span>
          <span className="about-headline-line">STUDENTS</span>
          <span className="about-headline-em about-headline-line">BUILD.</span>
        </h2>
        <p className="about-lead">
          CampusCode brings students, teams, organizers, and hackathons into one
          connected ecosystem.
        </p>
      </div>
      <div className="about-right">
        <div className="about-right-card" ref={cardRef}>
          <span className="about-cc-corner-top" aria-hidden="true" />
          <span className="about-cc-corner-bot" aria-hidden="true" />
          <span className="about-marker about-marker--lime" aria-hidden="true" />
          <span className="about-marker--lime about-marker--vr" aria-hidden="true" />
          <div className="about-cc-icon" ref={badgeRef} aria-hidden="true">
            <span className="about-cc-inner">CC</span>
          </div>
          <div className="about-cc-logo" ref={logoRef} aria-hidden="true">
            <CubeScene progress={progress} reducedMotion={reducedMotion} />
          </div>
          <p className="about-right-label">—</p>
          <h3 className="about-right-title">IDEAS BECOME REALITY.</h3>
          <p className="about-right-text">
            A connected space to discover hackathons, find teams, and turn ideas
            into shipped projects.
          </p>
        </div>
      </div>
    </section>
  );
}
